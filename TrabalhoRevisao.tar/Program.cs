﻿Veiculo v1 = new Veiculo();

Console.WriteLine("Digite o chassi do carro:");
v1.SetChassi(Console.ReadLine());
