﻿namespace TrabalhoRevisao.entidades
{
    public class ProprietarioPJ : Proprietario
    {
        public string idPJ;
        public string cnpj;
        public string razaoSocial;
        public string nomeFantasia;
        public string incricaoEstadual;
        public string atividadeEconomica;

    }
}

