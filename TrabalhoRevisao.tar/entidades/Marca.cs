﻿namespace TrabalhoRevisao.entidades
{
    public class Marca
    {
        public string idMarca;
        public string nome;
        public string observacao;
        public string localidade;

    }
}
