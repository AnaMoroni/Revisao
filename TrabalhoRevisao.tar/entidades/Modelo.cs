﻿namespace TrabalhoRevisao.entidades
{
    public class Modelo
    {
        public string idModelo;
        public string descricao;
        public string quantEixos;
        public string peso;
        public string quantPassageiros;
        public string cavalaria;
        public string cilindrada;
        public Marca marca;

    }
}
