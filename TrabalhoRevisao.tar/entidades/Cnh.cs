﻿namespace TrabalhoRevisao.entidades
{
    public class Cnh
    {
        public string idCnh;
        public string dataEmissao;
        public string dataVencimento;
        public string categoria;
        public string pontuacao;
        public string numero;
        public ProprietarioPF proprietario;

    }
}