﻿namespace TrabalhoRevisao.entidades
{
    public class Vistoria
    {
        public string idVistoria;
        public string data;
        public string hora;
        public string observacao;
        public string status;
        public Vistoriador vistoriador;
        public string veiculoV;

    }
}