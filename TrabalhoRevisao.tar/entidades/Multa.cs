﻿namespace TrabalhoRevisao.entidades
{
    public class Multa
    {
        public string idMulta;
        public string descricao;
        public string tipo;
        public string valorAtual;
        public string penalidade;
        public string fator;

    }
}