﻿namespace TrabalhoRevisao.entidades
{
    public class Vistoriador
    {
        public string idVistoriador;
        public string email;
        public string nome;
        public string cpf;
        public string dataAdmissao;
        public string status;
    }
}