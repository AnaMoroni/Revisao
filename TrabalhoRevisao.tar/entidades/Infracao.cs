﻿namespace TrabalhoRevisao.entidades
{
    public class Infracao
    {
        public string idInfracao;
        public string data;
        public string hora;
        public string localidade;
        public string valorAplicado;
        public string veiculoM;
        public Multa multa;
    }
}
