﻿namespace TrabalhoRevisao.entidades
{
    public class Cidade
    {
        public string idCidade;
        public string nome;
        public string codigoIbge;
        public Estado estado;

    }
}