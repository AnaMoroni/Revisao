﻿namespace TrabalhoRevisao.entidades
{
    public class Estado
    {
        public string idEstado;
        public string nome;
        public string sigla;
        public string pais;

    }
}
