﻿namespace TrabalhoRevisao.entidades
{
    public class Proprietario
    {
        public string situacao;
        public string email;
        public string telefone;
        public string endereco;
    }
}